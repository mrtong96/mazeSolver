
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
short_version = '1.10.0.post2'
version = '1.10.0.post2'
full_version = '1.10.0.post2'
git_revision = 'e905cad9646ad65316458bbc7f5c83a9d5ec8728'
release = True

if not release:
    version = full_version
